


numSamples = 1000;
numVariables = 7; 
data = zeros(numSamples, numVariables); 
labels = cell(numSamples, 1);

for i = 1:numSamples
  
    temperature = randi([20, 100]); 
    pressure = randi([100, 500]); 
    reactionTime = randi([1, 10]); 
    molecularWeight = rand(); 
    monomerConcentration = rand(); 
    initiatorConcentration = rand(); 
    catalystConcentration = rand(); 
    
    
    parameters = [temperature, pressure, reactionTime, ...
        molecularWeight, monomerConcentration, ...
     initiatorConcentration, catalystConcentration];
    polymerType = simulatePolymerProcess(parameters);
    
 
    data(i, :) = parameters;
    labels{i} = polymerType;
end


dataWithLabels = [num2cell(data), labels];


filename = 'elastomer_data.xlsx';
xlswrite(filename, dataWithLabels);
disp(['Data saved to ' filename]);
% Load the data from the Excel file


