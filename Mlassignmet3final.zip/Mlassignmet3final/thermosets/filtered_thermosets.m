
filename = 'thermoset_data.xlsx';


[~, txt, raw] = xlsread(filename);

% Get the column indices for the classification labels
labelColumn = size(raw, 2);

% Identify rows with "Other" classification and mark them for deletion
rowsToDelete = [];
for i = 1:size(raw, 1)
    if strcmp(raw{i, labelColumn}, 'Other')
        rowsToDelete = [rowsToDelete, i];
    end
end

% Delete rows with "Other" classification
raw(rowsToDelete, :) = [];

% Save the filtered data to a new Excel file
newFilename = 'filtered_thermosets_data.xlsx';
xlswrite(newFilename, raw);
disp(['Filtered data saved to ' newFilename]);