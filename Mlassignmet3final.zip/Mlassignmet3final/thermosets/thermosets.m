



numSamples = 2000; 
numVariables = 7; 
data = zeros(numSamples, numVariables); 
labels = cell(numSamples, 1);

for i = 1:numSamples
    % Generate random parameters within specified ranges for thermosets
    temperature = randi([20, 200]); % Example: random values between 20 and 200
    pressure = randi([50, 500]); % Example: random values between 50 and 500
    reactionTime = randi([1, 10]); % Example: random values between 1 and 10
    molecularWeight = rand(); % Example: random value between 0 and 1
    monomerConcentration = rand(); % Example: random value between 0 and 1
    initiatorConcentration = rand(); % Example: random value between 0 and 1
    catalystConcentration = rand(); % Example: random value between 0 and 1
    
    % Simulate polymerization process with the generated parameters
    parameters = [temperature, pressure, reactionTime, ...
        molecularWeight, monomerConcentration, ...
        initiatorConcentration, catalystConcentration];
    polymerType = simulatePolymerProcess(parameters);
    
    % Store simulated data and polymer types
    data(i, :) = parameters;
    labels{i} = polymerType;
end

% Step 3: Save Data to Excel
% Combine data and labels into a single cell array
dataWithLabels = [num2cell(data), labels];

% Write data to Excel file
filename = 'thermoset_data.xlsx';
xlswrite(filename, dataWithLabels);
disp(['Data saved to ' filename]);
