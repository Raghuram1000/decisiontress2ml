

numSamples = 1000; % Number of data points to generate
numVariables = 7; % Number of process variables (including the new parameters)
data = zeros(numSamples, numVariables); % Initialize matrix to store data
labels = cell(numSamples, 1); % Initialize cell array to store polymer types

for i = 1:numSamples
    % Generate random parameters within specified ranges for elastomers and thermosets
    temperature = randi([20, 100]); % Example: random values between 20 and 100
    pressure = randi([100, 500]); % Example: random values between 100 and 500
    reactionTime = randi([1, 10]); % Example: random values between 1 and 10
    molecularWeight = rand(); % Example: random value between 0 and 1
    monomerConcentration = rand(); % Example: random value between 0 and 1
    initiatorConcentration = rand(); % Example: random value between 0 and 1
    chainLength = randi([100, 1000]); % Example: random values between 100 and 1000
    
    % Simulate polymerization process with the generated parameters
    parameters = [temperature, pressure, reactionTime, ...
        molecularWeight, monomerConcentration, ...
        initiatorConcentration, chainLength];
    polymerType = simulatePolymerProcess(parameters);
    
    % Store simulated data and polymer types
    data(i, :) = parameters;
    labels{i} = polymerType;
end

% Step 3: Save Data to Excel
% Combine data and labels into a single cell array
dataWithLabels = [num2cell(data), labels];

% Write data to Excel file
filename = 'thermoplastic_data_with_noise.xlsx';
xlswrite(filename, dataWithLabels);
disp(['Data saved to ' filename]);
