
numSamples = 2500; % Number of data points to generate
numVariables = 7; % Number of process variables (including the new parameters)
data = zeros(numSamples, numVariables); % Initialize matrix to store data
labels = cell(numSamples, 1); % Initialize cell array to store polymer types

for i = 1:numSamples
    % Generate random parameters within specified ranges for thermoplastics
    temperature = randi([100, 300]); % Example: random values between 100 and 300
    pressure = randi([200, 700]); % Example: random values between 200 and 700
    reactionTime = randi([3, 15]); % Example: random values between 3 and 15
    molecularWeight = rand(); % Example: random value between 0 and 1
    monomerConcentration = rand(); % Example: random value between 0 and 1
    initiatorConcentration = rand(); % Example: random value between 0 and 1
    catalystConcentration = rand(); % 
    
    % Simulate polymerization process with the generated parameters
    parameters = [temperature, pressure, reactionTime, ...
        molecularWeight, monomerConcentration, ...
        initiatorConcentration, catalystConcentration];
    polymerType = simulatePolymerProcess(parameters);
    
 
    data(i, :) = parameters;
    labels{i} = polymerType;
end

% Step 3: Save Data to Excel
% Combine data and labels into a single cell array
dataWithLabels = [num2cell(data), labels];

% Write data to Excel file
filename = 'thermoplastic_data.xlsx';
xlswrite(filename, dataWithLabels);
disp(['Data saved to ' filename]);
